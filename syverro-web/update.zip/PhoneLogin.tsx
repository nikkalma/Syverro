// src/pages/PhoneLogin.tsx

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';

export default function PhoneLogin() {
  const navigate = useNavigate();
  const { login, phoneLogin, phoneRegister, setAuth } = useAuthStore();

  // Состояния формы
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [email, setEmail] = useState('');
  const [step, setStep] = useState<'phone' | 'code' | 'email'>('phone');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendTimer, setResendTimer] = useState(0);

  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

  // ===== ФОРМАТИРОВАНИЕ ТЕЛЕФОНА =====
  const formatPhone = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length <= 1) return `+${cleaned}`;
    if (cleaned.length <= 4) return `+${cleaned.slice(0, 1)} (${cleaned.slice(1)}`;
    if (cleaned.length <= 7) return `+${cleaned.slice(0, 1)} (${cleaned.slice(1, 4)}) ${cleaned.slice(4)}`;
    if (cleaned.length <= 9) return `+${cleaned.slice(0, 1)} (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
    return `+${cleaned.slice(0, 1)} (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7, 9)}-${cleaned.slice(9, 11)}`;
  };

  const getRawPhone = (value: string) => value.replace(/\D/g, '');

  // ===== ОТПРАВКА КОДА =====
  const sendCode = async () => {
    const rawPhone = getRawPhone(phone);
    if (rawPhone.length < 10) {
      setError('Введите корректный номер телефона');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await fetch(`${API_URL}/auth/phone/send-code`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: rawPhone }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Ошибка отправки кода');
      }

      setStep('code');
      setResendTimer(60);

      // Таймер для повторной отправки
      const timer = setInterval(() => {
        setResendTimer((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // ===== ПРОВЕРКА КОДА =====
  const verifyCode = async () => {
    if (code.length < 4) {
      setError('Введите код из SMS');
      return;
    }

    setLoading(true);
    setError('');

    try {
      let response;
      const rawPhone = getRawPhone(phone);

      if (mode === 'register') {
        // РЕГИСТРАЦИЯ
        response = await fetch(`${API_URL}/auth/phone/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phone: rawPhone,
            code,
            email: email || undefined,
          }),
        });
      } else {
        // ВХОД
        response = await fetch(`${API_URL}/auth/phone/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phone: rawPhone,
            code,
          }),
        });
      }

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Ошибка проверки кода');
      }

      // Получаем данные пользователя
      const userResponse = await fetch(`${API_URL}/auth/me`, {
        headers: { Authorization: `Bearer ${data.access_token}` },
      });

      if (!userResponse.ok) {
        throw new Error('Не удалось получить данные пользователя');
      }

      const user = await userResponse.json();

      // Сохраняем в store
      setAuth(data.access_token, user);

      // Редирект на главную
      navigate('/');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // ===== ПЕРЕКЛЮЧЕНИЕ РЕЖИМОВ =====
  const switchMode = () => {
    setMode(mode === 'login' ? 'register' : 'login');
    setStep('phone');
    setCode('');
    setError('');
    setEmail('');
  };

  // ===== РЕНДЕР =====
  return (
    <div
      style={{
        maxWidth: '400px',
        margin: '80px auto',
        padding: '20px',
        color: '#E6EDF3',
      }}
    >
      <h1 style={{ fontSize: '28px', marginBottom: '8px' }}>
        {mode === 'login' ? 'Вход' : 'Регистрация'}
      </h1>
      <p style={{ color: '#97A6BA', marginBottom: '32px' }}>
        {mode === 'login'
          ? 'Войдите по номеру телефона'
          : 'Создайте аккаунт по номеру телефона'}
      </p>

      {step === 'phone' ? (
        // ===== ШАГ 1: ВВОД ТЕЛЕФОНА =====
        <>
          <div style={{ marginBottom: '16px' }}>
            <label
              style={{
                display: 'block',
                color: '#97A6BA',
                fontSize: '14px',
                marginBottom: '4px',
              }}
            >
              Номер телефона
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(formatPhone(e.target.value))}
              placeholder="+7 (999) 999-99-99"
              style={{
                width: '100%',
                padding: '12px',
                background: 'rgba(18, 28, 36, 0.6)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: '8px',
                color: '#E6EDF3',
                fontSize: '16px',
                fontFamily: 'Inter, sans-serif',
                outline: 'none',
              }}
              autoFocus
            />
          </div>

          {mode === 'register' && (
            <div style={{ marginBottom: '16px' }}>
              <label
                style={{
                  display: 'block',
                  color: '#97A6BA',
                  fontSize: '14px',
                  marginBottom: '4px',
                }}
              >
                Email (опционально)
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@mail.com"
                style={{
                  width: '100%',
                  padding: '12px',
                  background: 'rgba(18, 28, 36, 0.6)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: '8px',
                  color: '#E6EDF3',
                  fontSize: '16px',
                  fontFamily: 'Inter, sans-serif',
                  outline: 'none',
                }}
              />
            </div>
          )}

          <button
            onClick={sendCode}
            disabled={loading || getRawPhone(phone).length < 10}
            style={{
              width: '100%',
              padding: '12px',
              background: '#5B86A1',
              border: 'none',
              borderRadius: '8px',
              color: '#0A1118',
              fontSize: '16px',
              fontWeight: '500',
              cursor:
                loading || getRawPhone(phone).length < 10
                  ? 'not-allowed'
                  : 'pointer',
              opacity: loading || getRawPhone(phone).length < 10 ? 0.6 : 1,
              fontFamily: 'Inter, sans-serif',
              transition: 'background 0.2s',
            }}
            onMouseEnter={(e) => {
              if (!loading && getRawPhone(phone).length >= 10) {
                e.currentTarget.style.background = '#4A7590';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = '#5B86A1';
            }}
          >
            {loading ? 'Отправка...' : 'Получить код по SMS'}
          </button>

          <button
            onClick={switchMode}
            style={{
              marginTop: '16px',
              background: 'none',
              border: 'none',
              color: '#5B86A1',
              cursor: 'pointer',
              fontSize: '14px',
              width: '100%',
              fontFamily: 'Inter, sans-serif',
              transition: 'color 0.2s',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#E6EDF3')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#5B86A1')}
          >
            {mode === 'login'
              ? 'Нет аккаунта? Зарегистрироваться'
              : 'Уже есть аккаунт? Войти'}
          </button>
        </>
      ) : (
        // ===== ШАГ 2: ВВОД КОДА =====
        <>
          <p style={{ color: '#97A6BA', marginBottom: '16px', fontSize: '14px' }}>
            Код отправлен на номер{' '}
            <strong style={{ color: '#E6EDF3' }}>{phone}</strong>
          </p>

          <div style={{ marginBottom: '16px' }}>
            <label
              style={{
                display: 'block',
                color: '#97A6BA',
                fontSize: '14px',
                marginBottom: '4px',
              }}
            >
              Код из SMS
            </label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
              placeholder="Введите код"
              maxLength={6}
              style={{
                width: '100%',
                padding: '12px',
                background: 'rgba(18, 28, 36, 0.6)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: '8px',
                color: '#E6EDF3',
                fontSize: '16px',
                letterSpacing: '4px',
                fontFamily: 'Inter, sans-serif',
                outline: 'none',
              }}
              autoFocus
            />
          </div>

          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: '16px',
            }}
          >
            <span style={{ color: '#97A6BA', fontSize: '13px' }}>
              {resendTimer > 0
                ? `Повторно через ${resendTimer}с`
                : 'Не пришёл код?'}
            </span>
            {resendTimer === 0 && (
              <button
                onClick={sendCode}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#5B86A1',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontFamily: 'Inter, sans-serif',
                  transition: 'color 0.2s',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#E6EDF3')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#5B86A1')}
              >
                Отправить повторно
              </button>
            )}
          </div>

          <button
            onClick={verifyCode}
            disabled={loading || code.length < 4}
            style={{
              width: '100%',
              padding: '12px',
              background: '#5B86A1',
              border: 'none',
              borderRadius: '8px',
              color: '#0A1118',
              fontSize: '16px',
              fontWeight: '500',
              cursor: loading || code.length < 4 ? 'not-allowed' : 'pointer',
              opacity: loading || code.length < 4 ? 0.6 : 1,
              fontFamily: 'Inter, sans-serif',
              transition: 'background 0.2s',
            }}
            onMouseEnter={(e) => {
              if (!loading && code.length >= 4) {
                e.currentTarget.style.background = '#4A7590';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = '#5B86A1';
            }}
          >
            {loading
              ? 'Проверка...'
              : mode === 'login'
              ? 'Войти'
              : 'Зарегистрироваться'}
          </button>

          <button
            onClick={() => {
              setStep('phone');
              setCode('');
              setError('');
            }}
            style={{
              marginTop: '12px',
              background: 'none',
              border: 'none',
              color: '#97A6BA',
              cursor: 'pointer',
              fontSize: '14px',
              width: '100%',
              fontFamily: 'Inter, sans-serif',
              transition: 'color 0.2s',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#E6EDF3')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#97A6BA')}
          >
            ← Изменить номер
          </button>
        </>
      )}

      {error && (
        <div
          style={{
            color: '#EF5350',
            marginTop: '16px',
            fontSize: '14px',
            padding: '12px',
            background: 'rgba(239,83,80,0.1)',
            borderRadius: '8px',
            border: '1px solid rgba(239,83,80,0.2)',
          }}
        >
          {error}
        </div>
      )}
    </div>
  );
}