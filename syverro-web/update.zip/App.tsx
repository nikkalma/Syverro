// src/App.tsx

import { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import LibraryPage from './pages/LibraryPage';
import BookPage from './pages/BookPage';
import Insights from './pages/Insights';
import WorldMap from './pages/WorldMap';
import Profile from './pages/Profile';
import MyLibraryPage from './pages/MyLibraryPage';
import Settings from './pages/Settings';
import PhoneLogin from './pages/PhoneLogin';

// ИСПОЛЬЗУЕМ НОВЫЙ useAuthStore ВМЕСТО AuthContext
import { useAuthStore } from './store/authStore';
import { useOffline } from './lib/offline';
import { setupSyncOnUnload } from './lib/offline/sync';
import { SyncBanner } from './components/SyncBanner';

// Компонент для защищённых маршрутов
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  
  if (!isAuthenticated) {
    return <PhoneLogin />;
  }
  
  return children;
}

function AppRoutes() {
  // Берём токен из localStorage напрямую для offline
  const token = localStorage.getItem('token');
  const { sync, unsyncedCount, hasUnsyncedEvents } = useOffline();

  useEffect(() => {
    sync();
    setupSyncOnUnload(token);

    const interval = setInterval(() => {
      if (hasUnsyncedEvents) {
        sync();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [token]);

  return (
    <>
      {unsyncedCount > 0 && <SyncBanner count={unsyncedCount} />}
      <Routes>
        {/* ПУБЛИЧНЫЕ МАРШРУТЫ (ДОСТУПНЫ ВСЕМ) */}
        <Route path="/" element={<Layout><LibraryPage /></Layout>} />
        <Route path="/book/:id" element={<Layout><BookPage /></Layout>} />
        <Route path="/worldmap" element={<Layout><WorldMap /></Layout>} />

        {/* ЗАЩИЩЁННЫЕ МАРШРУТЫ (ТОЛЬКО ДЛЯ АВТОРИЗОВАННЫХ) */}
        <Route
          path="/insights"
          element={
            <ProtectedRoute>
              <Layout><Insights /></Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Layout><Profile /></Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/my-library"
          element={
            <ProtectedRoute>
              <Layout><MyLibraryPage /></Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <ProtectedRoute>
              <Layout><Settings /></Layout>
            </ProtectedRoute>
          }
        />
      </Routes>
    </>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* ВХОД И РЕГИСТРАЦИЯ — ЧЕРЕЗ ТЕЛЕФОН */}
        <Route path="/login" element={<PhoneLogin />} />
        <Route path="/register" element={<PhoneLogin />} />
        {/* ОСНОВНЫЕ МАРШРУТЫ */}
        <Route path="/*" element={<AppRoutes />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;