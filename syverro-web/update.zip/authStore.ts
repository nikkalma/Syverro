// src/store/authStore.ts
import { create } from 'zustand';

interface User {
  id: string;
  phone: string;
  email: string | null;
  created_at: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  setAuth: (token: string, user: User) => void;
  login: (identifier: string, password: string) => Promise<void>;
  register: (email: string, password: string, phone?: string) => Promise<void>;
  phoneLogin: (phone: string, code: string) => Promise<void>;
  phoneRegister: (phone: string, code: string, email?: string) => Promise<void>;
  logout: () => void;
  checkAuth: () => void;
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

export const useAuthStore = create<AuthState>((set, get) => ({
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  token: localStorage.getItem('token') || null,
  isAuthenticated: !!localStorage.getItem('token'),
  isLoading: false,

  setAuth: (token: string, user: User) => {
    console.log("STEP: SET AUTH", { token, user });
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    set({ user, token, isAuthenticated: true });
  },

  checkAuth: () => {
    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('user') || 'null');
    set({
      token,
      user,
      isAuthenticated: !!token,
    });
  },

  login: async (email: string, password: string) => {
    console.log("STEP 1.1: LOGIN REQUEST START", { email });
    set({ isLoading: true });

    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      console.log("STEP 2: RESPONSE RAW", {
        status: response.status,
        ok: response.ok,
        statusText: response.statusText,
      });

      if (!response.ok) {
        const error = await response.json();
        console.log("STEP 2: RESPONSE ERROR", error);
        throw new Error(error.detail || 'Ошибка входа');
      }

      const data = await response.json();
      console.log("STEP 2: RESPONSE DATA", data);

      const token = data.access_token || data.token || data.access;
      console.log("STEP 3: EXTRACTED TOKEN", token);

      if (!token) {
        console.error("STEP 3: NO TOKEN FOUND IN RESPONSE", data);
        throw new Error('Токен не получен');
      }

      const userResponse = await fetch(`${API_URL}/auth/me`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (!userResponse.ok) {
        console.error("STEP 3.1: USER DATA FAILED", userResponse.status);
        throw new Error('Не удалось получить данные пользователя');
      }

      const user = await userResponse.json();
      console.log("STEP 3.1: USER DATA", user);

      set({ user, token, isAuthenticated: true });
      console.log("STEP 4: STORE STATE", get());

      console.log("STEP 5: LS BEFORE", { token: localStorage.getItem('token'), user: localStorage.getItem('user') });
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
      console.log("STEP 5: LS AFTER", { token: localStorage.getItem('token'), user: localStorage.getItem('user') });

      set({ isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  register: async (email: string, password: string, phone?: string) => {
    console.log("STEP 1.1: REGISTER REQUEST START", { email, phone });
    set({ isLoading: true });

    try {
      const payload: any = { email, password };
      if (phone) payload.phone = phone;

      const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      console.log("STEP 2: RESPONSE RAW", {
        status: response.status,
        ok: response.ok,
        statusText: response.statusText,
      });

      if (!response.ok) {
        const error = await response.json();
        console.log("STEP 2: RESPONSE ERROR", error);
        throw new Error(error.detail || 'Ошибка регистрации');
      }

      const data = await response.json();
      console.log("STEP 2: RESPONSE DATA", data);

      const { login } = get();
      await login(email, password);
      set({ isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  phoneLogin: async (phone: string, code: string) => {
    console.log("📱 PHONE LOGIN START", { phone });
    set({ isLoading: true });

    try {
      const response = await fetch(`${API_URL}/auth/phone/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, code }),
      });

      console.log("📱 PHONE LOGIN RESPONSE", {
        status: response.status,
        ok: response.ok,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Ошибка входа по телефону');
      }

      const data = await response.json();
      const token = data.access_token;

      const userResponse = await fetch(`${API_URL}/auth/me`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const user = await userResponse.json();

      set({ user, token, isAuthenticated: true });
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));

      set({ isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  phoneRegister: async (phone: string, code: string, email?: string) => {
    console.log("📱 PHONE REGISTER START", { phone, email });
    set({ isLoading: true });

    try {
      const payload: any = { phone, code };
      if (email) payload.email = email;

      const response = await fetch(`${API_URL}/auth/phone/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      console.log("📱 PHONE REGISTER RESPONSE", {
        status: response.status,
        ok: response.ok,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Ошибка регистрации по телефону');
      }

      const data = await response.json();
      const token = data.access_token;

      const userResponse = await fetch(`${API_URL}/auth/me`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const user = await userResponse.json();

      set({ user, token, isAuthenticated: true });
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));

      set({ isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  logout: () => {
    console.log("STEP: LOGOUT");
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    set({ user: null, token: null, isAuthenticated: false });
  },
}));