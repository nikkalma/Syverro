// src/pages/Settings.tsx

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { storageService } from '../services/storageService';
import { getLocaleData, getBrowserLocale, localePriority, Locale } from '../locales';

export default function Settings() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const profile = storageService.getReaderProfile();

  // ===== СОСТОЯНИЯ =====
  const [displayName, setDisplayName] = useState(profile.displayName || '');
  const [status, setStatus] = useState(profile.status || '');
  const [theme, setTheme] = useState(localStorage.getItem('syverro_theme') || 'dark');
  const [locale, setLocale] = useState<Locale>(() => {
    const saved = localStorage.getItem('syverro_locale') as Locale | null;
    return saved || getBrowserLocale();
  });

  // ===== ТЕЛЕФОН =====
  const [phone, setPhone] = useState(user?.phone || '');
  const [newPhone, setNewPhone] = useState('');
  const [phoneCode, setPhoneCode] = useState('');
  const [phoneStep, setPhoneStep] = useState<'view' | 'edit' | 'code'>('view');
  const [phoneLoading, setPhoneLoading] = useState(false);
  const [phoneError, setPhoneError] = useState('');
  const [phoneMessage, setPhoneMessage] = useState('');

  // ===== EMAIL =====
  const [email, setEmail] = useState(user?.email || '');
  const [newEmail, setNewEmail] = useState('');
  const [emailPassword, setEmailPassword] = useState('');
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailError, setEmailError] = useState('');
  const [emailMessage, setEmailMessage] = useState('');

  // ===== ОБЩИЕ =====
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');

  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
  const t = getLocaleData(locale);

  // ===== ТЕМА =====
  useEffect(() => {
    document.documentElement.style.backgroundColor = theme === 'light' ? '#F5F5F5' : '#0B1220';
    document.documentElement.style.color = theme === 'light' ? '#1A1A1A' : '#E6EDF3';
    localStorage.setItem('syverro_theme', theme);
  }, [theme]);

  // ===== ФОРМАТ ТЕЛЕФОНА =====
  const formatPhone = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length <= 1) return `+${cleaned}`;
    if (cleaned.length <= 4) return `+${cleaned.slice(0, 1)} (${cleaned.slice(1)}`;
    if (cleaned.length <= 7) return `+${cleaned.slice(0, 1)} (${cleaned.slice(1, 4)}) ${cleaned.slice(4)}`;
    if (cleaned.length <= 9) return `+${cleaned.slice(0, 1)} (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
    return `+${cleaned.slice(0, 1)} (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7, 9)}-${cleaned.slice(9, 11)}`;
  };

  const getRawPhone = (value: string) => value.replace(/\D/g, '');

  // ===== ОТПРАВКА КОДА ДЛЯ ТЕЛЕФОНА =====
  const sendPhoneCode = async () => {
    const raw = getRawPhone(newPhone);
    if (raw.length < 10) {
      setPhoneError('Введите корректный номер телефона');
      return;
    }

    setPhoneLoading(true);
    setPhoneError('');
    setPhoneMessage('');

    try {
      const response = await fetch(`${API_URL}/auth/phone/send-code`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ phone: raw }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Ошибка отправки кода');
      }

      setPhoneStep('code');
      setPhoneMessage('Код отправлен на новый номер');
    } catch (err: any) {
      setPhoneError(err.message);
    } finally {
      setPhoneLoading(false);
    }
  };

  // ===== ПРОВЕРКА КОДА ДЛЯ ТЕЛЕФОНА =====
  const verifyPhoneCode = async () => {
    if (phoneCode.length < 4) {
      setPhoneError('Введите код из SMS');
      return;
    }

    setPhoneLoading(true);
    setPhoneError('');
    setPhoneMessage('');

    try {
      const raw = getRawPhone(newPhone);
      const response = await fetch(`${API_URL}/auth/phone/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          phone: raw,
          code: phoneCode,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Ошибка проверки кода');
      }

      setPhone(raw);
      setPhoneMessage('✅ Телефон успешно обновлён!');
      setPhoneStep('view');

      // Обновляем пользователя в store
      const userResponse = await fetch(`${API_URL}/auth/me`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });
      const userData = await userResponse.json();
      localStorage.setItem('user', JSON.stringify(userData));

      // Перезагружаем страницу для обновления данных
      setTimeout(() => window.location.reload(), 1000);
    } catch (err: any) {
      setPhoneError(err.message);
    } finally {
      setPhoneLoading(false);
    }
  };

  // ===== ДОБАВЛЕНИЕ EMAIL =====
  const addEmail = async () => {
    if (!newEmail) {
      setEmailError('Введите email');
      return;
    }
    if (!emailPassword) {
      setEmailError('Введите пароль для подтверждения');
      return;
    }

    setEmailLoading(true);
    setEmailError('');
    setEmailMessage('');

    try {
      const response = await fetch(`${API_URL}/auth/email/add`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          email: newEmail,
          password: emailPassword,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Ошибка добавления email');
      }

      setEmail(newEmail);
      setEmailMessage('✅ Email успешно добавлен!');
      setNewEmail('');
      setEmailPassword('');

      // Обновляем пользователя
      const userResponse = await fetch(`${API_URL}/auth/me`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });
      const userData = await userResponse.json();
      localStorage.setItem('user', JSON.stringify(userData));
      setTimeout(() => window.location.reload(), 1000);
    } catch (err: any) {
      setEmailError(err.message);
    } finally {
      setEmailLoading(false);
    }
  };

  // ===== СОХРАНЕНИЕ ПРОФИЛЯ =====
  const handleSave = () => {
    setIsSaving(true);
    setSaveMessage('');

    try {
      storageService.updateReaderProfile({
        displayName: displayName.trim() || 'Читатель',
        status: status.trim(),
      });

      localStorage.setItem('syverro_locale', locale);

      setSaveMessage('✅ Настройки сохранены');
      setTimeout(() => setSaveMessage(''), 3000);
    } catch (error) {
      setSaveMessage('❌ Ошибка сохранения');
    } finally {
      setIsSaving(false);
    }
  };

  // ===== ВЫХОД =====
  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // ===== ЯЗЫКИ =====
  const localeLabels: Record<Locale, string> = {
    ru: 'Русский',
    en: 'English',
    kk: 'Қазақша',
    uk: 'Українська',
    be: 'Беларуская',
    sr: 'Српски',
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '40px 24px' }}>
      <h1 style={{ fontSize: '28px', fontWeight: '300', color: '#E6EDF3', marginBottom: '32px' }}>
        ⚙️ {t.settings?.title || 'Настройки'}
      </h1>

      {/* ===== ОСНОВНЫЕ НАСТРОЙКИ ===== */}
      <div
        style={{
          background: 'rgba(18, 28, 36, 0.6)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          borderRadius: '16px',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          padding: '24px',
          marginBottom: '20px',
        }}
      >
        <h2 style={{ fontSize: '18px', color: '#E6EDF3', marginBottom: '20px' }}>
          👤 Профиль
        </h2>

        {/* Имя */}
        <div style={{ marginBottom: '20px' }}>
          <label style={{ fontSize: '13px', color: '#97A6BA', display: 'block', marginBottom: '6px' }}>
            Имя
          </label>
          <input
            type="text"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            placeholder="Читатель"
            style={{
              width: '100%',
              padding: '10px 14px',
              background: 'rgba(0,0,0,0.3)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '8px',
              color: '#E6EDF3',
              fontSize: '14px',
              fontFamily: 'Inter, sans-serif',
              outline: 'none',
            }}
          />
        </div>

        {/* Статус */}
        <div style={{ marginBottom: '20px' }}>
          <label style={{ fontSize: '13px', color: '#97A6BA', display: 'block', marginBottom: '6px' }}>
            Статус
          </label>
          <input
            type="text"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            placeholder="Пришла читать"
            style={{
              width: '100%',
              padding: '10px 14px',
              background: 'rgba(0,0,0,0.3)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '8px',
              color: '#E6EDF3',
              fontSize: '14px',
              fontFamily: 'Inter, sans-serif',
              outline: 'none',
            }}
          />
        </div>

        {/* Тема */}
        <div style={{ marginBottom: '20px' }}>
          <label style={{ fontSize: '13px', color: '#97A6BA', display: 'block', marginBottom: '6px' }}>
            Тема
          </label>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button
              onClick={() => setTheme('dark')}
              style={{
                flex: 1,
                padding: '10px',
                background: theme === 'dark' ? 'rgba(91, 134, 161, 0.25)' : 'rgba(255,255,255,0.05)',
                border: theme === 'dark' ? '1px solid rgba(91, 134, 161, 0.3)' : '1px solid rgba(255,255,255,0.08)',
                borderRadius: '8px',
                color: theme === 'dark' ? '#E6EDF3' : '#97A6BA',
                fontSize: '14px',
                cursor: 'pointer',
                fontFamily: 'Inter, sans-serif',
                transition: 'all 0.2s',
              }}
            >
              🌙 Тёмная
            </button>
            <button
              onClick={() => setTheme('light')}
              style={{
                flex: 1,
                padding: '10px',
                background: theme === 'light' ? 'rgba(91, 134, 161, 0.25)' : 'rgba(255,255,255,0.05)',
                border: theme === 'light' ? '1px solid rgba(91, 134, 161, 0.3)' : '1px solid rgba(255,255,255,0.08)',
                borderRadius: '8px',
                color: theme === 'light' ? '#E6EDF3' : '#97A6BA',
                fontSize: '14px',
                cursor: 'pointer',
                fontFamily: 'Inter, sans-serif',
                transition: 'all 0.2s',
              }}
            >
              ☀️ Светлая
            </button>
          </div>
        </div>

        {/* Язык */}
        <div style={{ marginBottom: '20px' }}>
          <label style={{ fontSize: '13px', color: '#97A6BA', display: 'block', marginBottom: '6px' }}>
            Язык
          </label>
          <select
            value={locale}
            onChange={(e) => setLocale(e.target.value as Locale)}
            style={{
              width: '100%',
              padding: '10px 14px',
              background: 'rgba(0,0,0,0.3)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '8px',
              color: '#E6EDF3',
              fontSize: '14px',
              fontFamily: 'Inter, sans-serif',
              outline: 'none',
            }}
          >
            {localePriority.map((l) => (
              <option key={l} value={l}>
                {localeLabels[l]}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={handleSave}
          disabled={isSaving}
          style={{
            width: '100%',
            padding: '12px',
            background: '#5B86A1',
            border: 'none',
            borderRadius: '8px',
            color: '#0A1118',
            fontSize: '14px',
            fontWeight: '600',
            cursor: isSaving ? 'default' : 'pointer',
            opacity: isSaving ? 0.6 : 1,
            fontFamily: 'Inter, sans-serif',
            transition: 'background 0.2s',
          }}
          onMouseEnter={(e) => {
            if (!isSaving) e.currentTarget.style.background = '#4A7590';
          }}
          onMouseLeave={(e) => {
            if (!isSaving) e.currentTarget.style.background = '#5B86A1';
          }}
        >
          {isSaving ? '💾 Сохранение...' : '💾 Сохранить настройки'}
        </button>

        {saveMessage && (
          <div
            style={{
              marginTop: '12px',
              textAlign: 'center',
              fontSize: '14px',
              color: saveMessage.includes('✅') ? '#4CAF50' : '#EF5350',
            }}
          >
            {saveMessage}
          </div>
        )}
      </div>

      {/* ===== ТЕЛЕФОН ===== */}
      <div
        style={{
          background: 'rgba(18, 28, 36, 0.6)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          borderRadius: '16px',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          padding: '24px',
          marginBottom: '20px',
        }}
      >
        <h2 style={{ fontSize: '18px', color: '#E6EDF3', marginBottom: '20px' }}>
          📱 Телефон
        </h2>

        {phoneStep === 'view' ? (
          <div>
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '12px 16px',
                background: 'rgba(0,0,0,0.2)',
                borderRadius: '8px',
                border: '1px solid rgba(255,255,255,0.06)',
              }}
            >
              <span style={{ color: '#E6EDF3', fontSize: '14px' }}>
                {phone || 'Не привязан'}
              </span>
              <button
                onClick={() => {
                  setNewPhone('');
                  setPhoneCode('');
                  setPhoneError('');
                  setPhoneMessage('');
                  setPhoneStep('edit');
                }}
                style={{
                  padding: '4px 12px',
                  background: 'rgba(91, 134, 161, 0.15)',
                  border: '1px solid rgba(91, 134, 161, 0.2)',
                  borderRadius: '6px',
                  color: '#5B86A1',
                  fontSize: '12px',
                  cursor: 'pointer',
                  fontFamily: 'Inter, sans-serif',
                }}
              >
                {phone ? 'Изменить' : 'Привязать'}
              </button>
            </div>
            {phone && (
              <p style={{ color: '#4CAF50', fontSize: '13px', marginTop: '8px' }}>
                ✅ Телефон привязан
              </p>
            )}
          </div>
        ) : phoneStep === 'edit' ? (
          <div>
            <input
              type="tel"
              value={newPhone}
              onChange={(e) => setNewPhone(formatPhone(e.target.value))}
              placeholder="+7 (999) 999-99-99"
              style={{
                width: '100%',
                padding: '10px 14px',
                background: 'rgba(0,0,0,0.3)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: '8px',
                color: '#E6EDF3',
                fontSize: '14px',
                fontFamily: 'Inter, sans-serif',
                outline: 'none',
                marginBottom: '12px',
              }}
              autoFocus
            />
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                onClick={sendPhoneCode}
                disabled={phoneLoading || getRawPhone(newPhone).length < 10}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: '#5B86A1',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#0A1118',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: phoneLoading || getRawPhone(newPhone).length < 10 ? 'not-allowed' : 'pointer',
                  opacity: phoneLoading || getRawPhone(newPhone).length < 10 ? 0.6 : 1,
                  fontFamily: 'Inter, sans-serif',
                }}
              >
                {phoneLoading ? 'Отправка...' : 'Отправить код'}
              </button>
              <button
                onClick={() => {
                  setPhoneStep('view');
                  setPhoneError('');
                }}
                style={{
                  padding: '10px 20px',
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: '8px',
                  color: '#97A6BA',
                  fontSize: '14px',
                  cursor: 'pointer',
                  fontFamily: 'Inter, sans-serif',
                }}
              >
                Отмена
              </button>
            </div>
            {phoneError && (
              <div style={{ color: '#EF5350', marginTop: '12px', fontSize: '13px' }}>
                {phoneError}
              </div>
            )}
            {phoneMessage && (
              <div style={{ color: '#4CAF50', marginTop: '12px', fontSize: '13px' }}>
                {phoneMessage}
              </div>
            )}
          </div>
        ) : (
          <div>
            <p style={{ color: '#97A6BA', fontSize: '14px', marginBottom: '12px' }}>
              Код отправлен на номер {newPhone}
            </p>
            <input
              type="text"
              value={phoneCode}
              onChange={(e) => setPhoneCode(e.target.value.replace(/\D/g, ''))}
              placeholder="Введите код из SMS"
              maxLength={6}
              style={{
                width: '100%',
                padding: '10px 14px',
                background: 'rgba(0,0,0,0.3)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: '8px',
                color: '#E6EDF3',
                fontSize: '14px',
                letterSpacing: '4px',
                fontFamily: 'Inter, sans-serif',
                outline: 'none',
                marginBottom: '12px',
              }}
              autoFocus
            />
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                onClick={verifyPhoneCode}
                disabled={phoneLoading || phoneCode.length < 4}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: '#5B86A1',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#0A1118',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: phoneLoading || phoneCode.length < 4 ? 'not-allowed' : 'pointer',
                  opacity: phoneLoading || phoneCode.length < 4 ? 0.6 : 1,
                  fontFamily: 'Inter, sans-serif',
                }}
              >
                {phoneLoading ? 'Проверка...' : 'Подтвердить'}
              </button>
              <button
                onClick={() => {
                  setPhoneStep('edit');
                  setPhoneCode('');
                  setPhoneError('');
                }}
                style={{
                  padding: '10px 20px',
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: '8px',
                  color: '#97A6BA',
                  fontSize: '14px',
                  cursor: 'pointer',
                  fontFamily: 'Inter, sans-serif',
                }}
              >
                Назад
              </button>
            </div>
            {phoneError && (
              <div style={{ color: '#EF5350', marginTop: '12px', fontSize: '13px' }}>
                {phoneError}
              </div>
            )}
            {phoneMessage && (
              <div style={{ color: '#4CAF50', marginTop: '12px', fontSize: '13px' }}>
                {phoneMessage}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ===== EMAIL ===== */}
      <div
        style={{
          background: 'rgba(18, 28, 36, 0.6)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          borderRadius: '16px',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          padding: '24px',
          marginBottom: '20px',
        }}
      >
        <h2 style={{ fontSize: '18px', color: '#E6EDF3', marginBottom: '20px' }}>
          📧 Email
        </h2>

        {email ? (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '12px 16px',
              background: 'rgba(0,0,0,0.2)',
              borderRadius: '8px',
              border: '1px solid rgba(255,255,255,0.06)',
            }}
          >
            <span style={{ color: '#E6EDF3', fontSize: '14px' }}>{email}</span>
            <span style={{ color: '#4CAF50', fontSize: '13px' }}>✅ Подтверждён</span>
          </div>
        ) : (
          <div>
            <p style={{ color: '#97A6BA', fontSize: '14px', marginBottom: '12px' }}>
              Добавьте email для восстановления аккаунта
            </p>
            <input
              type="email"
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="example@mail.com"
              style={{
                width: '100%',
                padding: '10px 14px',
                background: 'rgba(0,0,0,0.3)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: '8px',
                color: '#E6EDF3',
                fontSize: '14px',
                fontFamily: 'Inter, sans-serif',
                outline: 'none',
                marginBottom: '12px',
              }}
            />
            <input
              type="password"
              value={emailPassword}
              onChange={(e) => setEmailPassword(e.target.value)}
              placeholder="Введите пароль для подтверждения"
              style={{
                width: '100%',
                padding: '10px 14px',
                background: 'rgba(0,0,0,0.3)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: '8px',
                color: '#E6EDF3',
                fontSize: '14px',
                fontFamily: 'Inter, sans-serif',
                outline: 'none',
                marginBottom: '12px',
              }}
            />
            <button
              onClick={addEmail}
              disabled={emailLoading || !newEmail || !emailPassword}
              style={{
                width: '100%',
                padding: '10px',
                background: '#5B86A1',
                border: 'none',
                borderRadius: '8px',
                color: '#0A1118',
                fontSize: '14px',
                fontWeight: '500',
                cursor: emailLoading || !newEmail || !emailPassword ? 'not-allowed' : 'pointer',
                opacity: emailLoading || !newEmail || !emailPassword ? 0.6 : 1,
                fontFamily: 'Inter, sans-serif',
              }}
            >
              {emailLoading ? 'Добавление...' : 'Добавить email'}
            </button>
            {emailError && (
              <div style={{ color: '#EF5350', marginTop: '12px', fontSize: '13px' }}>
                {emailError}
              </div>
            )}
            {emailMessage && (
              <div style={{ color: '#4CAF50', marginTop: '12px', fontSize: '13px' }}>
                {emailMessage}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ===== АККАУНТ ===== */}
      <div
        style={{
          background: 'rgba(18, 28, 36, 0.6)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          borderRadius: '16px',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          padding: '24px',
        }}
      >
        <h2 style={{ fontSize: '18px', color: '#E6EDF3', marginBottom: '20px' }}>
          🔐 Аккаунт
        </h2>

        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '12px 16px',
            background: 'rgba(0,0,0,0.2)',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.06)',
            marginBottom: '12px',
          }}
        >
          <span style={{ color: '#97A6BA', fontSize: '14px' }}>ID пользователя</span>
          <span style={{ color: '#E6EDF3', fontSize: '14px', fontFamily: 'monospace' }}>
            {user?.id?.slice(0, 8) || '-'}…
          </span>
        </div>

        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '12px 16px',
            background: 'rgba(0,0,0,0.2)',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.06)',
            marginBottom: '12px',
          }}
        >
          <span style={{ color: '#97A6BA', fontSize: '14px' }}>Телефон</span>
          <span style={{ color: '#E6EDF3', fontSize: '14px' }}>
            {phone || '—'}
          </span>
        </div>

        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '12px 16px',
            background: 'rgba(0,0,0,0.2)',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.06)',
            marginBottom: '20px',
          }}
        >
          <span style={{ color: '#97A6BA', fontSize: '14px' }}>Email</span>
          <span style={{ color: '#E6EDF3', fontSize: '14px' }}>
            {email || '—'}
          </span>
        </div>

        <button
          onClick={handleLogout}
          style={{
            width: '100%',
            padding: '12px',
            background: 'transparent',
            border: '1px solid #EF5350',
            borderRadius: '8px',
            color: '#EF5350',
            fontSize: '14px',
            cursor: 'pointer',
            transition: 'all 0.2s',
            fontFamily: 'Inter, sans-serif',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(239, 83, 80, 0.1)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
          }}
        >
          🚪 Выйти из аккаунта
        </button>
      </div>
    </div>
  );
}